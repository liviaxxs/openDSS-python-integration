
import os
import pathlib
import random
import pandas as pd
import py_dss_interface
from py_dss_toolkit import dss_tools
from SimulacaoDSS import SimulacaoDSS  # supondo que sua classe esteja neste arquivo

def main():
    # =====================
    # 1. Inicializa a simulação
    # =====================
    sim = SimulacaoDSS()
    
    # =====================
    # 2. Compila o arquivo DSS
    # =====================
    arquivo_dss = "ieee37.dss"  # coloque o nome do seu arquivo DSS aqui
    sim.iniciar_arquivo_dss(arquivo_dss)
    
    # =====================
    # 3. Sorteia linhas aleatórias
    # =====================
    num_linhas = 5
    linhas_sorteadas = sim.sorteio_linhas_aleatorias(X=num_linhas)
    
    # =====================
    # 4. Configura monitores antes da falta
    # =====================
    sim.configurar_monitores_antes_falta(linhas_sorteadas)
    
    # =====================
    # 5. Aplica faltas
    # =====================
    barra_falta = 802            # pode ser alterada ou sorteada também
    resistencia_falta = 5        # resistência da falta
    fases = None                 # None = aplica todos os tipos, ou 1, 2 ou 3
    
    sim.aplicar_faltas(barra_falta, resistencia_falta, fases=fases)
    
    # =====================
    # 6. Configura monitores depois da falta
    # =====================
    sim.configurar_monitores_depois_falta(linhas_sorteadas)
    
    print("\n✅ Simulação finalizada!")

if __name__ == "__main__":
    main()
