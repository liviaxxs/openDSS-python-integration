#Unir o loop de mudar o local da falta com o de modificar o 
# tipo e resistencia em um unico codigo. Fazer em poo. 
# Usar um metodo pra cada modificacao.
import os
import pathlib
import random
import pandas as pd
import py_dss_interface
from py_dss_toolkit import dss_tools
class SimulacaoDSS:
    def __init__(self):
        # caminhos fixos
        self.script_path = os.path.dirname(os.path.abspath(__file__))
        self.xlsx_path = pathlib.Path(self.script_path, "lines_bus1.xlsx")

        # cria pastas uma única vez
        self.export_dir = pathlib.Path(self.script_path, "Antes")
        self.export_dir.mkdir(parents=True, exist_ok=True)

        self.export_dir_fault = pathlib.Path(self.script_path, "Depois")
        self.export_dir_fault.mkdir(parents=True, exist_ok=True)

        # instancia DSS uma vez
        self.dss = py_dss_interface.DSS()
        dss_tools.update_dss(self.dss)

    def iniciar_arquivo_dss(self, arquivo_dss):
        dss_file = pathlib.Path(self.script_path, arquivo_dss)
        self.dss.text(f"compile [{dss_file}]")
        self.dss.text("set mode=snap")
    
    def configurar_monitores_antes_falta(self, linhas_selecionadas):
        for ln, _ in linhas_selecionadas:
            elem = f"Line.{ln}"
            self.dss.text(f"New Monitor.{ln}_power    element={elem} terminal=1 mode=1 ppolar=no")
            self.dss.text(f"New Monitor.{ln}_voltage  element={elem} terminal=1 mode=0")
            self.dss.text(f"New Monitor.{ln}_losses   element={elem} terminal=1 mode=9")
            self.dss.text(f"New Monitor.{ln}_seqMag   element={elem} terminal=1 mode=48")
            self.dss.text(f"New EnergyMeter.{ln}_meter element={elem} terminal=1")
            print(f"Monitors/Meter criados para {elem}")
    def configurar_monitores_depois_falta(self, linhas_selecionadas):
        for ln, _ in linhas_selecionadas:
            elem = f"Line.{ln}"
            self.dss.text(f"New Monitor.{ln}_power_fault    element={elem} terminal=1 mode=1 ppolar=no")
            self.dss.text(f"New Monitor.{ln}_voltage_fault  element={elem} terminal=1 mode=0")
            self.dss.text(f"New Monitor.{ln}_losses_fault   element={elem} terminal=1 mode=9")
            self.dss.text(f"New Monitor.{ln}_seqMag_fault   element={elem} terminal=1 mode=48")
            self.dss.text(f"New EnergyMeter.{ln}_meter_fault element={elem} terminal=1")
            print(f"Monitors/Meter criados para {elem}")

    def aplicar_faltas(self, barra_falta, resistencia_falta, fases=None):
    # ======== Falta monofásica ========
        if fases is None or fases == 1:
          for n in range(1, 4):
            nome_falta = f"FT_phase_{n}"
            self.dss.text(f"New Fault.{nome_falta} bus1={barra_falta}.{n} phases=1 r={resistencia_falta}")
            print(f"⚡ Falta monofásica aplicada: {nome_falta} em {barra_falta}.{n}")
            self.resolver_falta(nome_falta)

    # ======== Falta bifásica com terra ========
        if fases is None or fases == 2:
           for n in range(1, 4):
              for m in range(n + 1, 4):
                nome_falta_bifasica_terra = f"FT_phase_{n}{m}_T"
                self.dss.text(f"New Fault.{nome_falta_bifasica_terra} bus1={barra_falta}.{n}{m} phases=2 r={resistencia_falta}")
                print(f"⚡ Falta bifásica + terra aplicada: {nome_falta_bifasica_terra}")
                self.resolver_falta(nome_falta_bifasica_terra)

    # ======== Falta bifásica sem terra ========
        if fases is None or fases == 2:
            for n in range(1, 4):
              for m in range(n + 1, 4):
                nome_falta_bifasica = f"FT_phase_{n}{m}"
                self.dss.text(f"New Fault.{nome_falta_bifasica} bus1={barra_falta}.{n} bus2={barra_falta}.{m} phases=2 r={resistencia_falta}")
                print(f"⚡ Falta bifásica sem terra aplicada: {nome_falta_bifasica}")
                self.resolver_falta(nome_falta_bifasica)

    # ======== Falta trifásica ========
        if fases is None or fases == 3:
          nome_falta_trifasica = "FT_trifasica"
          self.dss.text(f"New Fault.{nome_falta_trifasica} bus1={barra_falta}.1.2.3 phases=3 r={resistencia_falta}")
          print(f"⚡ Falta trifásica aplicada")
          self.resolver_falta(nome_falta_trifasica)

    def resolver_falta(self, nome_falta):
         self.dss.text("reset monitors")
         self.dss.text("calcv")
         self.dss.text("set mode=snap")
         self.dss.text("solve")
         print(f"✅ Solução para {nome_falta} executada com sucesso.")
         self.dss.text("sample")

         nome_arquivo_csv = f"Mon_Falta_{nome_falta}"
         self.dss.text(f"set casename={nome_arquivo_csv}")
         self.dss.text("Export All Monitors")
         csv_path = os.path.join(self.script_path, f"{nome_arquivo_csv}.CSV")
         if not os.path.exists(csv_path):
          csv_path = os.path.join(self.script_path, f"{nome_arquivo_csv.lower()}_1.csv")

         self.dss.text(f"edit fault.{nome_falta} enabled=no")

    
    def sorteio_linhas_aleatorias(self, X=5):
      df = pd.read_excel(self.xlsx_path, dtype={"line": str, "bus1": str})
      df = df[["line", "bus1"]].dropna()
      line_bus1 = list(df.itertuples(index=False, name=None))
      X = min(X, len(line_bus1))
      selection = random.sample(line_bus1, k=X)
      sorted_lines = [ln for ln, _ in selection]
      print("Lines sorteadas:", sorted_lines)
      return selection  # retorna lista de tuplas (line, bus1) para aplicar faltas






